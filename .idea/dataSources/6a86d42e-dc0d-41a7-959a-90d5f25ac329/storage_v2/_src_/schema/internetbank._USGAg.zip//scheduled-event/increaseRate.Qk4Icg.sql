create definer = root@localhost event increaseRate on schedule
    every '1' YEAR
        starts '2021-05-05 11:21:46'
    enable
    do
    BEGIN
UPDATE card as c, admin as a set c.balance=c.balance*(1+a.interestRate) where c.state <> 'frozen';
END;

