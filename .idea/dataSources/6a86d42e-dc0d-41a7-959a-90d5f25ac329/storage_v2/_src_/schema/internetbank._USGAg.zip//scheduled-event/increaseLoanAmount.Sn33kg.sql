create definer = root@localhost event increaseLoanAmount on schedule
    every '1' YEAR
        starts '2021-06-06 11:13:04'
    enable
    do
    BEGIN
update loan as l, admin as a set l.amount=l.amount*(1+a.loanRate);
END;

